﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.IO;

namespace RepairFileWindows
{
    public partial class RepairFileWindowsService : ServiceBase
    {
        public static string repairDirectory = @"C:/BkavEnterprise/ReportPy/BkavReportProcessor_Endpoint/report_to_soc/";
        public static string logDirectory = @"C:/RepairFileWindows/log/";
        public static uint deleteTime = 600;
        public static uint intervalTime = 30;
        public RepairFileWindowsService()
        {
            InitializeComponent();
        }
        public static void ProcessDirectory(string targetDirectory)
        {
            double currentTime = (DateTime.Now.Subtract(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Local))).TotalSeconds;
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string filePath in fileEntries)
            {
                if (File.Exists(filePath) && Path.GetExtension(filePath).Equals(".xml"))
                {
                    double fileCreatedTime = (File.GetCreationTime(filePath).Subtract(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Local))).TotalSeconds;
                    ProcessFile(filePath, fileCreatedTime, currentTime);
                }
            }
        }
        public static void ProcessFile(string filePath, double fileCreatedTime, double currentTime)
        {
            if ((currentTime - fileCreatedTime) > deleteTime)
            {
                File.Delete(filePath);
            }

            if ((currentTime - fileCreatedTime) <= intervalTime)
            {
                using (StreamWriter sw = new StreamWriter(filePath, true))
                {
                    sw.WriteLine();
                }
            }
        }
        public void OnTimer(object sender, ElapsedEventArgs args)
        {
            if (Directory.Exists(repairDirectory))
            {
                ProcessDirectory(repairDirectory);
            }
        }
        protected override void OnStart(string[] args)
        {
            Timer timer = new Timer();
            timer.Interval = 10000; // 10 seconds
            timer.Elapsed += new ElapsedEventHandler(this.OnTimer);
            timer.Start();

            if (!Directory.Exists(logDirectory))
            {
                System.IO.Directory.CreateDirectory(logDirectory);
            }
            string serviceLogName = string.Concat(DateTime.Now.ToString("yyyy.MM.dd"), ".log");
            using (StreamWriter sw = new StreamWriter(string.Concat(logDirectory, serviceLogName), true))
            {
                sw.WriteLine("[{0}] Service started", DateTime.Now);
            }
        }

        protected override void OnStop()
        {
            string serviceLogName = string.Concat(DateTime.Now.ToString("yyyy.MM.dd"), ".log");
            using (StreamWriter sw = new StreamWriter(string.Concat(logDirectory, serviceLogName), true))
            {
                sw.WriteLine("[{0}] Service stopped", DateTime.Now);
            }
        }
    }
}
