# Get data from Redis
Steps:
1.	bash create_service.sh
2.	sudo systemctl status redis-pull.service
